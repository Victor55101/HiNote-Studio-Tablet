# HiNote Studio Tablet — Android / Huawei MatePad

Esta edición usa el mismo motor PencilEngine/HiNote de la versión de escritorio, pero la interfaz es táctil y corre dentro de una app Android sin depender de la laptop durante el uso diario.

## Compatibilidad objetivo
- HUAWEI MatePad Pro 12.2 2025 internacional
- HarmonyOS 4.3
- Arquitectura arm64-v8a

## Qué funciona
- Edición de texto en la tablet.
- Tamaño, color y opacidad por selección.
- Cambio de mayúsculas/minúsculas.
- Listas básicas y subniveles con Enter/Tab.
- Sangría, interlineado y espaciado.
- Previsualización paginada usando los mismos strokes que se exportan.
- Exportación local `.hinote` usando el selector de archivos del sistema.
- No requiere Internet después de instalar el APK.
- No requiere conectar la tablet a la laptop para crear notas.

## Arquitectura
La app contiene:
- interfaz WebView responsive (HTML/CSS/JS),
- Python embebido mediante Chaquopy,
- el banco `glyphs_v11.json`,
- `template_1stroke.hinote`,
- compositor y writer PencilEngine originales.

No usa Pillow ni Matplotlib en Android. La previsualización se dibuja con Canvas y los thumbnails se generan como JPEG desde la propia interfaz.

## Compilar APK una sola vez
Este repositorio está listo para Android Studio / Gradle.

### Android Studio
1. Instala Android Studio.
2. Abre esta carpeta como proyecto.
3. Espera a que Gradle sincronice.
4. `Build > Build APK(s)`.
5. El APK aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions
También se incluye `.github/workflows/build-apk.yml`.
Al subir el proyecto a GitHub y ejecutar el workflow `Build HiNote Studio APK`, el APK se genera como artefacto descargable.

## Instalar en la MatePad
1. Copia o descarga `app-debug.apk` en la tablet.
2. Abre **Archivos > Descargas**.
3. Toca el APK e instala.
4. Si HarmonyOS lo solicita, autoriza la instalación de aplicaciones desde esa fuente.
5. Abre **HiNote Studio** desde el escritorio.

## Exportar una nota
1. Escribe/pega el texto.
2. Revisa la previsualización.
3. Toca **Guardar .hinote**.
4. Elige una carpeta en la tablet.
5. Abre/importa ese `.hinote` desde Huawei Notes.

## Nota de desarrollo
El APK debug sirve para instalar en tu propia tablet. Para distribuir públicamente conviene crear un keystore y una build release firmada.

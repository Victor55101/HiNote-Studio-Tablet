from __future__ import annotations

import base64
import json
import tempfile
from pathlib import Path

from handwriting_composer import compose_document, page_view
from mobile_hinote_writer import build_hinote_multi
from pencilengine_writer import write_pencilengine
from validate_hinote import validate_hinote


def _settings(raw: str):
    s = json.loads(raw or "{}")
    return {
        "seed": int(s.get("seed", 12345)),
        "letter_spacing": float(s.get("letter_spacing", 0.0)),
        "word_spacing": float(s.get("word_spacing", 26.0)),
        "line_grid_rows": max(1, int(s.get("line_grid_rows", 1))),
        "wrap_tolerance": float(s.get("wrap_tolerance", 12.0)),
        "margin_bottom": float(s.get("margin_bottom", 55.0)),
        "list_indent_squares": max(0, int(s.get("list_indent_squares", 1))),
        "auto_line_spacing": bool(s.get("auto_line_spacing", True)),
    }


def _compose(project_dir: str, document_json: str, settings_json: str):
    project = Path(project_dir)
    doc = json.loads(document_json)
    s = _settings(settings_json)
    return compose_document(project / "glyphs_v11.json", doc, **s)


def compose(project_dir: str, document_json: str, settings_json: str) -> str:
    return json.dumps(_compose(project_dir, document_json, settings_json), ensure_ascii=False, separators=(",", ":"))


def export_hinote(project_dir: str, document_json: str, settings_json: str, thumbnails_json: str, title: str, output_path: str) -> str:
    project = Path(project_dir)
    comp = _compose(project_dir, document_json, settings_json)
    thumbs = json.loads(thumbnails_json)
    if len(thumbs) != len(comp.get("pages", [])):
        raise ValueError("La cantidad de previews no coincide con las páginas")

    with tempfile.TemporaryDirectory(prefix="hinote_tablet_") as td:
        work = Path(td)
        bins = []
        jpgs = []
        for i, _ in enumerate(comp["pages"]):
            pcomp = page_view(comp, i)
            bin_path = work / f"page_{i+1}.bin"
            write_pencilengine(pcomp, project / "template_1stroke.hinote", bin_path)
            bins.append(bin_path)

            data = thumbs[i]
            if "," in data:
                data = data.split(",", 1)[1]
            jpg = work / f"page_{i+1}.jpg"
            jpg.write_bytes(base64.b64decode(data))
            jpgs.append(jpg)

        out = Path(output_path)
        build_hinote_multi(project / "template_1stroke.hinote", bins, out, title=title or "Nueva nota", thumbnails=jpgs)
        if not validate_hinote(out):
            raise RuntimeError("La nota generada no pasó la validación local")
    return str(output_path)

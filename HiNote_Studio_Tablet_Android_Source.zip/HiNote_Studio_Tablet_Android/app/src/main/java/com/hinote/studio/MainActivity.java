package com.hinote.studio;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.chaquo.python.AndroidPlatform;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int REQUEST_SAVE = 501;
    private WebView webView;
    private PyObject backend;
    private String pendingDoc, pendingSettings, pendingThumbs, pendingTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(15, 23, 42));
        getWindow().setNavigationBarColor(Color.rgb(15, 23, 42));

        copyEngineAsset("glyphs_v11.json");
        copyEngineAsset("template_1stroke.hinote");

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        backend = Python.getInstance().getModule("mobile_backend");

        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private void copyEngineAsset(String name) {
        File out = new File(getFilesDir(), name);
        if (out.exists() && out.length() > 0) return;
        try (InputStream in = getAssets().open(name); FileOutputStream fos = new FileOutputStream(out)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
        } catch (Exception e) {
            throw new RuntimeException("No se pudo preparar " + name, e);
        }
    }

    public class Bridge {
        @JavascriptInterface
        public String compose(String documentJson, String settingsJson) {
            try {
                return backend.callAttr("compose", getFilesDir().getAbsolutePath(), documentJson, settingsJson).toString();
            } catch (Exception e) {
                return "{\"error\":" + quoteJson(e.getMessage()) + "}";
            }
        }

        @JavascriptInterface
        public void requestSave(String title, String documentJson, String settingsJson, String thumbnailsJson) {
            pendingTitle = title;
            pendingDoc = documentJson;
            pendingSettings = settingsJson;
            pendingThumbs = thumbnailsJson;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/octet-stream");
                String safe = (title == null || title.trim().isEmpty()) ? "Nueva nota" : title.trim();
                safe = safe.replaceAll("[\\\\/:*?\"<>|]", "_");
                intent.putExtra(Intent.EXTRA_TITLE, safe + ".hinote");
                startActivityForResult(intent, REQUEST_SAVE);
            });
        }

        @JavascriptInterface
        public String platformInfo() {
            return "HarmonyOS/Android · HiNote Studio Tablet";
        }
    }

    private static String quoteJson(String s) {
        if (s == null) s = "Error desconocido";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\"";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_SAVE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        new Thread(() -> {
            try {
                File tmp = new File(getCacheDir(), "exported_note.hinote");
                backend.callAttr("export_hinote",
                        getFilesDir().getAbsolutePath(), pendingDoc, pendingSettings,
                        pendingThumbs, pendingTitle, tmp.getAbsolutePath());
                try (InputStream in = new java.io.FileInputStream(tmp); OutputStream out = getContentResolver().openOutputStream(uri)) {
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                runOnUiThread(() -> {
                    Toast.makeText(this, "HiNote guardado correctamente", Toast.LENGTH_LONG).show();
                    webView.evaluateJavascript("window.onExportComplete(true, 'Nota guardada');", null);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    webView.evaluateJavascript("window.onExportComplete(false, " + quoteJson(e.getMessage()) + ");", null);
                });
            }
        }).start();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
